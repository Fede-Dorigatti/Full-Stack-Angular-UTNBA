import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  valor1: number = 0;
  valor2: number = 0;
  resultado = 0;
  sumar() {
    this.resultado = this.valor1 + this.valor2;
  }
}
