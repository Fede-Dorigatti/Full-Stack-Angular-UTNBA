import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  valor1: number = 0;
  valor2: number = 0;
  resultado = 0;
  paises = ['Argentina', 'Uruguay', 'Brasil'];
  productos = [
    {
      id: 1,
      title: 'Moto G',
    },
    {
      id: 2,
      title: 'Moto X',
    },
    {
      id: 3,
      title: 'Moto Z',
    },
  ];
  sumar() {
    this.resultado = this.valor1 + this.valor2;
  }
  cambiarProductos() {
    this.productos = [
      {
        id: 1,
        title: 'Moto G',
      },
    ];
  }
}
