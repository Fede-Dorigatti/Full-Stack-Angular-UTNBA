import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  valor1: number = 0;
  valor2: number = 0;
  resultado = 0;
  cssResultadosClass = '';
  sumar() {
    this.resultado = this.valor1 + this.valor2;
    if (this.resultado > 0) {
      this.cssResultadosClass = 'ok';
    } else if (this.resultado < 0) {
      this.cssResultadosClass = 'error';
    } else {
      this.cssResultadosClass = '';
    }
  }
}
