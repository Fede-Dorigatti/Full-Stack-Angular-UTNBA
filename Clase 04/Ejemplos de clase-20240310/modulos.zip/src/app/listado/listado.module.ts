import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndexComponent } from './index/index.component';
import { FiltrosComponent } from './filtros/filtros.component';

@NgModule({
  declarations: [IndexComponent, FiltrosComponent],
  imports: [CommonModule],
  exports: [IndexComponent],
})
export class ListadoModule {}
