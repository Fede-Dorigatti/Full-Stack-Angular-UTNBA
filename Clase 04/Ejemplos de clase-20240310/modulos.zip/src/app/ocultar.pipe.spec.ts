import { OcultarPipe } from './ocultar.pipe';

describe('OcultarPipe', () => {
  it('create an instance', () => {
    const pipe = new OcultarPipe();
    expect(pipe).toBeTruthy();
  });
});
