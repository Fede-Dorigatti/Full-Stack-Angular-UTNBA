import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ProductosService {
  constructor(private http: HttpClient) {}
  getAll() {
    return [
      {
        id: 1,
        title: 'Moto G',
      },
      {
        id: 2,
        title: 'Moto X',
      },
      {
        id: 3,
        title: 'Moto Z',
      },
    ];
  }
}
