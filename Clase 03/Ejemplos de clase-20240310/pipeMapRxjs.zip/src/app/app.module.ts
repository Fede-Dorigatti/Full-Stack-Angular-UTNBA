import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; //Incluir
import { RegistroComponent } from './registro/registro.component';
import { HttpClientModule } from '@angular/common/http'; //Incluir

@NgModule({
  declarations: [AppComponent, HomeComponent, RegistroComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule, //Incluir
    FormsModule, //Incluir
    ReactiveFormsModule, //Incluir
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
